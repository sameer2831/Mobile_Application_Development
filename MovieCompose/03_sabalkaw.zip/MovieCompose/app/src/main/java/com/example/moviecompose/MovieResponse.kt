package com.example.moviecompose
import android.os.Parcelable
import kotlinx.parcelize.Parcelize
import java.util.UUID
data class MovieResponse(
    val results: List<Movie>
)
@Parcelize
data class Movie(
    val id: String = UUID.randomUUID().toString(),
    val title: String,
    val overview: String,
    val poster_path: String,
    val release_date: String,
    val vote_average: Float,
    val vote_count: Int
): Parcelable
