package com.example.moviecompose

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.expandVertically
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Star
import androidx.compose.runtime.*
import androidx.compose.runtime.livedata.observeAsState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.unit.dp
import coil.compose.rememberImagePainter

@Composable
fun MovieListScreen(
    viewModel: MovieViewModel,
    onMovieSelected: (Movie) -> Unit,
    onBackClick: () -> Unit
) {
    val movies by viewModel.movies.observeAsState(emptyList())
    var selectedMovies by remember { mutableStateOf(listOf<Movie>()) }
    var sortAscending by remember { mutableStateOf(true) } // Tracks sorting direction

    Column(modifier = Modifier.fillMaxSize()) {
        // Top App Bar
        TopAppBar(
            navigationIcon={
                IconButton( onClick =onBackClick){
                    Icon(Icons.Filled.ArrowBack, contentDescription = "Back")
                }
            },
            title = { Text("Movie List") },
            backgroundColor = Color(0xFF789868)

        )

        // Row for "Select All", "Clear All", "Delete" buttons
        Row(
            modifier = Modifier
                .padding(8.dp)
                .fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Button(onClick = {
                // Select all movies
                selectedMovies = movies
            },colors = ButtonDefaults.buttonColors(backgroundColor = Color(0xFF93AC86),contentColor = Color.White)) {
                Text("Select All")
            }

            Button(onClick = {
                // Clear all selections
                selectedMovies = emptyList()
            },colors = ButtonDefaults.buttonColors(backgroundColor = Color(0xFF93AC86),contentColor = Color.White)) {
                Text("Clear All")
            }

            Button(onClick = {
                // Delete selected movies
                viewModel.deleteMovies(selectedMovies)
                selectedMovies = emptyList() // Clear the selections after deletion
            },colors = ButtonDefaults.buttonColors(backgroundColor = Color(0xFF93AC86),contentColor = Color.White)) {
                Text("Delete")
            }

            // Sort Button to toggle between increasing and decreasing order
            Button(onClick = {
                sortAscending = !sortAscending
                viewModel.sortMoviesByRating(sortAscending)
            },colors = ButtonDefaults.buttonColors(backgroundColor = Color(0xFF93AC86),contentColor = Color.White)) {
                Text(if (sortAscending) "Sort ↑" else "Sort ↓")
            }
        }

        // LazyColumn to display list of movies
        LazyColumn(modifier = Modifier.fillMaxSize()
            .background(color = Color(0xFFD6E0D1))) {
            items(movies) { movie ->
                // Use AnimatedVisibility only for deletion animation
                AnimatedVisibility(
                    visible = true, // Always visible unless deleted
                    enter = expandVertically(),
                    exit = shrinkVertically()
                ) {
                    MovieRow(
                        movie = movie,
                        isSelected = selectedMovies.any { it.id == movie.id }, // Compare using the movie ID
                        onMovieClick = { onMovieSelected(movie) },
                        onCheckBoxClick = {
                            // Toggle movie selection by checking the movie's ID
                            selectedMovies = if (selectedMovies.any { it.id == movie.id }) {
                                selectedMovies - movie
                            } else {
                                selectedMovies + movie
                            }
                        },
                        onMovieLongClick = {
                            // Duplicate movie when long-pressed
                            viewModel.duplicateMovie(movie)
                        }
                    )
                }
            }
        }
    }
}

@Composable
fun RatingBar(rating: Float, modifier: Modifier = Modifier, numStars: Int = 5) {
    Row(modifier = modifier) {
        for (i in 1..numStars) {
            Icon(
                imageVector = if (i <= rating) Icons.Default.Star else Icons.Default.Star,
                contentDescription = null,
                tint = if (i <= rating) Color.Yellow else Color.Gray
            )
        }
    }
}

@Composable
fun MovieRow(
    movie: Movie,
    isSelected: Boolean,
    onMovieClick: () -> Unit,
    onCheckBoxClick: () -> Unit,
    onMovieLongClick: () -> Unit // Long press to duplicate
) {
    // Different layout based on rating
    if (movie.vote_average >= 4.0f) {
        // Layout for movies with rating >= 4.0 (Image on the left)
        MovieRowLayout(
            movie = movie,
            imageOnLeft = true,
            isSelected = isSelected,
            onMovieClick = onMovieClick,
            onCheckBoxClick = onCheckBoxClick,
            onMovieLongClick = onMovieLongClick
        )
    } else {
        // Layout for movies with rating < 4.0 (Image on the right)
        MovieRowLayout(
            movie = movie,
            imageOnLeft = false,
            isSelected = isSelected,
            onMovieClick = onMovieClick,
            onCheckBoxClick = onCheckBoxClick,
            onMovieLongClick = onMovieLongClick
        )
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun MovieRowLayout(
    movie: Movie,
    imageOnLeft: Boolean,
    isSelected: Boolean,
    onMovieClick: () -> Unit,
    onCheckBoxClick: () -> Unit,
    onMovieLongClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .padding(8.dp)
            .fillMaxWidth()
            .combinedClickable(
                onClick = onMovieClick,
                onLongClick = onMovieLongClick // Long press for duplication
            ),
        elevation = 4.dp
    ) {
        Row(
            modifier = Modifier.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Conditionally place image on the left or right
            if (imageOnLeft) {
                MovieImage(movie.poster_path)
                Spacer(modifier = Modifier.width(8.dp))
            }

            Column(modifier = Modifier.weight(1f)) {
                Text(text = movie.title, style = MaterialTheme.typography.h6)
                Text(text = "Release Date: ${movie.release_date}")
                RatingBar(rating = movie.vote_average / 2, numStars = 5)
            }

            Spacer(modifier = Modifier.width(8.dp))

            if (!imageOnLeft) {
                MovieImage(movie.poster_path)
            }

            Checkbox(
                checked = isSelected,
                onCheckedChange = { onCheckBoxClick() }
            )
        }
    }
}

@Composable
fun MovieImage(posterPath: String) {
    val imageUrl = "https://image.tmdb.org/t/p/w500${posterPath}"
    Image(
        painter = rememberImagePainter(imageUrl),
        contentDescription = null,
        modifier = Modifier.size(64.dp),
        contentScale = ContentScale.Crop
    )
}