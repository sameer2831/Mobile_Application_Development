package com.example.moviecompose

import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentActivity
import androidx.viewpager2.adapter.FragmentStateAdapter

class ViewPagerAdapter(fragmentActivity: FragmentActivity, private val movies: List<Movie>) :
    FragmentStateAdapter(fragmentActivity) {
    override fun getItemCount(): Int = movies.size

    override fun createFragment(position: Int): Fragment {
        return MovieDetailFragment.newInstance(movies[position])
    }
}
