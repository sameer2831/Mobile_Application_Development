package com.example.moviecompose

import com.google.accompanist.pager.ExperimentalPagerApi
import com.google.accompanist.pager.HorizontalPager
import com.google.accompanist.pager.rememberPagerState
import kotlinx.coroutines.launch
import androidx.compose.foundation.Image
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.foundation.layout.*
import androidx.compose.material.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import coil.compose.rememberImagePainter
@Composable
fun MovieDetailScreen(movieId: String?, viewModel: MovieViewModel, onBackClick: () -> Unit) {
    // Fetch movie based on ID (filter it from the list of movies)
    val movie = viewModel.getMovieById(movieId)

    movie?.let {
        Scaffold(
            topBar = {
                TopAppBar(
                    backgroundColor = Color(0xFF789868),
                    title = { Text(it.title) },
                    navigationIcon = {
                        IconButton(onClick = { onBackClick() }) {
                            Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                        }
                    }
                )
            }
        ) { paddingValues ->
            Box(modifier = Modifier.padding(paddingValues)) {
                MovieCard(movie = it)
            }
        }
    } ?: run {
        // If the movie is not found, display an error message or fallback UI
        Text("Movie not found")
    }
}

@Composable
fun MovieCard(movie: Movie) {
    Card(
        modifier = Modifier
            .padding(16.dp)
            .fillMaxWidth(),
        elevation = 4.dp
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            val imageUrl = "https://image.tmdb.org/t/p/w500${movie.poster_path}"

            Image(
                painter = rememberImagePainter(imageUrl),
                contentDescription = null,
                modifier = Modifier
                    .height(200.dp)
                    .fillMaxWidth(),
                contentScale = ContentScale.Crop
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text(text = movie.title, style = MaterialTheme.typography.h6)
            Text(text = "Release Date: ${movie.release_date}")
            RatingBar(rating = movie.vote_average / 2, numStars = 5)
            Spacer(modifier = Modifier.height(8.dp))
            Text(text = movie.overview, style = MaterialTheme.typography.body1)
        }
    }
}
@OptIn(ExperimentalPagerApi::class)
@Composable
fun MovieDetailPagerScreen(
    movies: List<Movie>,
    startMovieId: String?,
    onBackClick: () -> Unit
) {
    val initialPage = movies.indexOfFirst { it.title == startMovieId }
    val pagerState = rememberPagerState(initialPage)
    val coroutineScope = rememberCoroutineScope()

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(movies[pagerState.currentPage].title) },
                navigationIcon = {
                    IconButton(onClick = { onBackClick() }) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { paddingValues ->
        HorizontalPager(
            count = movies.size,
            state = pagerState,
            modifier = Modifier.padding(paddingValues)
        ) { page ->
            MovieCard(movie = movies[page])
        }
    }
}
