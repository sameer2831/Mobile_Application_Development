package com.example.moviecompose

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.google.accompanist.pager.ExperimentalPagerApi
import com.google.accompanist.pager.HorizontalPager
import com.google.accompanist.pager.rememberPagerState
import kotlinx.coroutines.launch

@OptIn(ExperimentalPagerApi::class)
@Composable
fun MoviePagerScreen(
    movies: List<Movie>,
    onBackClick: () -> Unit // Callback for back navigation
) {
    val pagerState = rememberPagerState()
    val coroutineScope = rememberCoroutineScope()

    Column(modifier = Modifier
        .background(color = Color(0xFFD6E0D1))
        .fillMaxSize())
         {
        // Back Button
        TopAppBar(modifier = Modifier.background(color=Color(0xFF005942)),
            title = { Text("Movie Details") },
            backgroundColor = Color(0xFF789868),
            navigationIcon = {
                IconButton(onClick = onBackClick) {
                    Icon(Icons.Filled.ArrowBack, contentDescription = "Back")
                }
            }
        )

        LazyRow(
            modifier = Modifier
                .background(color=Color(0xFFD1E8E2))
                .fillMaxWidth()
        ) {
            items(movies) { movie ->
                val index = movies.indexOf(movie)
                Tab(
                    selected = pagerState.currentPage == index,
                    onClick = {
                        coroutineScope.launch {
                            pagerState.animateScrollToPage(index)
                        }
                    },
                    modifier = Modifier
                        .width(120.dp)
                        .padding(top=15.dp)
                        .background(
                            if(pagerState.currentPage == index) Color(0xFF8EC7B7)
                            else Color.Transparent),
                    text = { Text(movie.title) }
                )
            }
        }

        // Spacer for better visual separation
        Spacer(modifier = Modifier.height(8.dp))

        // HorizontalPager to swipe between movies
        HorizontalPager(
            count = movies.size,
            state = pagerState,
            modifier = Modifier.fillMaxSize()
        ) { page ->
            MovieCard(movie = movies[page])
        }
    }
}
