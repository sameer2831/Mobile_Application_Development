package com.example.moviecompose

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.livedata.observeAsState
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.moviecompose.ui.theme.MovieComposeTheme

class MainActivity : ComponentActivity() {
    // Create an instance of MovieViewModel using the viewModels() delegate
    private val movieViewModel: MovieViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MovieComposeTheme {
                // Set up NavController
                val navController = rememberNavController()
                var movieList by remember { mutableStateOf<List<Movie>>(emptyList()) }

                // Call to fetch movies on app start
                LaunchedEffect(Unit) {
                    val apiKey = BuildConfig.TMDB_API_KEY // Ensure this is configured correctly
                    movieViewModel.fetchPopularMovies(apiKey)
                }
                movieViewModel.movies.observeAsState(emptyList()).value.let { movies ->
                    if (movies.isNotEmpty()) {
                        movieList = movies // Update the movieList state variable
                    }
                }
                NavHost(
                    navController = navController,
                    startDestination = "home"
                ) {
                    composable("home") { HomeScreen(navController) }
                    composable("movie_pager") { MoviePagerScreen(movieList,onBackClick = {
                        // Handle back press
                        onBackPressedDispatcher.onBackPressed()
                    }) }
                    // Movie List Screen Route
                    composable("movie_list") {
                        MovieListScreen(
                            viewModel = movieViewModel,
                            onMovieSelected = { selectedMovie ->
                                // Navigate to movie details when a movie is clicked
                                navController.navigate("movie_detail/${selectedMovie.title}")
                            },
                            onBackClick = {
                                // Handle back press
                                onBackPressedDispatcher.onBackPressed()
                            }
                        )
                    }

                    // Movie Detail Screen Route With Pager
                    composable("movie_detail/{movieId}") { backStackEntry ->

                        val movieId = backStackEntry.arguments?.getString("movieId")
                        val movies = movieViewModel.movies.value.orEmpty()
                        // Show Movie Detail Pager Screen
                        MovieDetailPagerScreen(
                            movies = movies,
                            startMovieId = movieId ?: "",
                            onBackClick = {
                                navController.popBackStack()
                            }
                        )
                    }
                }
            }
        }
    }
}
