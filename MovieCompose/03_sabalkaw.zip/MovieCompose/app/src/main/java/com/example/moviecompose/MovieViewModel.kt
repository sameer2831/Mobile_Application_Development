package com.example.moviecompose

import androidx.annotation.OptIn
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.media3.common.util.Log
import androidx.media3.common.util.UnstableApi
import kotlinx.coroutines.launch
import retrofit2.Response
import java.util.UUID

class MovieViewModel : ViewModel() {
    private val _movies = MutableLiveData<List<Movie>>()
    val movies: LiveData<List<Movie>> = _movies

    @OptIn(UnstableApi::class)
    fun fetchPopularMovies(apiKey: String) {
        viewModelScope.launch {
            try {
                val response: Response<MovieResponse> = RetrofitClient.instance.getPopularMovies(apiKey, 1)

                if (response.isSuccessful) {
                    val movieResults = response.body()?.results ?: emptyList()
                    _movies.postValue(movieResults)
                    // Log the fetched movie results to check if the data is coming
                    Log.d("MovieViewModel", "Movies fetched: ${movieResults.size}")
                } else {
                    _movies.postValue(emptyList())
                    Log.e("MovieViewModel", "Failed to fetch movies: ${response.message()}")
                }
            } catch (e: Exception) {
                e.printStackTrace()
                _movies.postValue(emptyList())
                Log.e("MovieViewModel", "Exception: ${e.message}")
            }
        }
    }
    fun getMovieById(movieId: String?): Movie? {
        return _movies.value?.find { it.title == movieId } // Match the movie by title or unique identifier
    }
    fun deleteMovies(moviesToDelete: List<Movie>) {
        _movies.value = _movies.value?.filterNot { it in moviesToDelete }
    }

    fun duplicateMovie(movie: Movie) {
        val currentMovies = _movies.value?.toMutableList() ?: mutableListOf()
        val index = currentMovies.indexOf(movie)
        if (index != -1) {
            // Duplicate the movie with a new unique ID
            val duplicatedMovie = movie.copy(id = UUID.randomUUID().toString())
            currentMovies.add(index + 1, duplicatedMovie)
            _movies.postValue(currentMovies)
        }
    }

    fun sortMoviesByRating(ascending: Boolean) {
        _movies.value = _movies.value?.sortedWith(compareBy { if (ascending) it.vote_average else -it.vote_average })
    }
}
