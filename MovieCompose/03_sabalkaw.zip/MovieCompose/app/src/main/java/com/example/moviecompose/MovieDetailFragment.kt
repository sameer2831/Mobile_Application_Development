package com.example.moviecompose

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import com.example.moviecompose.databinding.FragmentMovieDetailBinding
import kotlinx.parcelize.Parcelize
import android.os.Parcelable

class MovieDetailFragment : Fragment() {

    companion object {
        private const val ARG_MOVIE = "arg_movie"

        fun newInstance(movie: Movie): MovieDetailFragment {
            val fragment = MovieDetailFragment()
            val args = Bundle()
            args.putParcelable(ARG_MOVIE, movie) // Movie should implement Parcelable
            fragment.arguments = args
            return fragment
        }
    }

    private var _binding: FragmentMovieDetailBinding? = null
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentMovieDetailBinding.inflate(inflater, container, false)
        val movie: Movie? = arguments?.getParcelable(ARG_MOVIE)

        // Set movie details in the view
        binding.movieTitle.text = movie?.title
        binding.movieYear.text = "Release Date: ${movie?.release_date}"
        binding.movieDescription.text = movie?.overview
        binding.ratingBar.rating = (movie?.vote_average?.div(2) ?: 0f)

        return binding.root
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
