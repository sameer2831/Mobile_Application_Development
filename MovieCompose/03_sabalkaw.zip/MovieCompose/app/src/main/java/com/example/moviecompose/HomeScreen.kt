package com.example.moviecompose

import android.media.Image
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material.Button
import androidx.compose.material.ButtonDefaults
import androidx.compose.material.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController

@Composable
fun HomeScreen(navController: NavController) {
    Column(modifier = Modifier
        .background(color = Color(0xFFD6E0D1))
        .fillMaxSize(),
        horizontalAlignment = Alignment.CenterHorizontally, // Align children horizontally to the center
        verticalArrangement = Arrangement.Center) {
        Image(
            painter = painterResource(id = R.drawable.homescreen), // Add your image resource here
            contentDescription = "Home Screen Image", // Provide a content description for accessibility
            modifier = Modifier
                .height(300.dp) // Set the height for the image
                .fillMaxWidth() // Make the image fill the width of the screen
                .padding(bottom = 16.dp) // Add space below the image
        )

        Button( onClick = { navController.navigate("movie_list") },
            colors = ButtonDefaults.buttonColors(backgroundColor = Color(0xFF789868),contentColor = Color.White)) {
            Text(text = "View Movies in RecyclerView")
        }

        Spacer(modifier = Modifier.height(16.dp))

        Button(onClick = { navController.navigate("movie_pager") },
            colors = ButtonDefaults.buttonColors(backgroundColor = Color(0xFF789868),contentColor = Color.White)) {
            Text(text = "View Movies in ViewPager")
        }
    }
}
